<nav class="bg-white border-bottom">
    <div class="container d-flex justify-content-between align-items-center py-2">
        <?php if(Auth::check() && Auth::user()->role == '2'): ?>
            <a href="<?php echo e(route('dashboard')); ?>" class="h5 mb-0 text-decoration-none">
                <img class="evoting-logo" src="<?php echo e(asset('images/eVotingLogo.png')); ?>" alt="Evoting Logo">
            </a>
        <?php else: ?>
            <a href="<?php echo e(route('voterHistory')); ?>" class="h5 mb-0 text-decoration-none">
                <img class="evoting-logo" src="<?php echo e(asset('images/eVotingLogo.png')); ?>" alt="Evoting Logo">
            </a>
        <?php endif; ?>

        <!-- <div class="d-none d-sm-flex align-items-center gap-3">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">Dashboard</a>
        </div> -->

        <div class="d-none d-sm-flex align-items-center gap-2">
            <?php if(auth()->guard()->check()): ?>
                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?>

                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">Profile</a></li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>" class="m-0 p-0">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item">Log Out</button>
                            </form>
                        </li>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary btn-sm">Log in</a>
            <?php endif; ?>
        </div>

        <!-- Mobile toggle -->
        <button id="mobileToggle" class="btn btn-outline-secondary d-sm-none">☰</button>
    </div>

    <div id="mobileMenu" class="d-none p-2 border-top">
        <a href="<?php echo e(route('dashboard')); ?>" class="d-block py-1">Dashboard</a>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('profile.edit')); ?>" class="d-block py-1">Profile</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="py-1">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-link p-0">Log Out</button>
            </form>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="d-block py-1">Log in</a>
        <?php endif; ?>
    </div>

    <script>
        (function(){
            var toggle = document.getElementById('mobileToggle');
            var mobileMenu = document.getElementById('mobileMenu');
            if (toggle && mobileMenu) {
                toggle.addEventListener('click', function () {
                    mobileMenu.classList.toggle('d-none');
                });
            }
        })();
    </script>
</nav>
<?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>