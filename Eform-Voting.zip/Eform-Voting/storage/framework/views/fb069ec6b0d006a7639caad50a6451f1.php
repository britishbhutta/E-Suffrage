<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Tariff Purchase Invoice</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f9f9f9;
      padding: 20px;
      color: #333;
    }
    .invoice-container {
      max-width: 700px;
      margin: auto;
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 30px;
    }
    h2, h3 {
      margin-bottom: 10px;
      color: #222;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 25px;
    }
    table th, table td {
      text-align: left;
      padding: 10px;
      border-bottom: 1px solid #eee;
    }
    .total {
      font-weight: bold;
      font-size: 16px;
      color: #000;
    }
    .footer {
      margin-top: 20px;
      font-size: 12px;
      color: #777;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="invoice-container">
    <h2>Invoice</h2>
    <p><strong>Date:</strong> <?php echo new \Illuminate\Support\EncodedHtmlString(date('Y-m-d')); ?></p>

    <!-- User Details -->
    <h3>User Details</h3>
    <table>
      <tr>
        <th>First Name</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($user->first_name); ?></td>
      </tr>
      <tr>
        <th>Last Name</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($user->last_name); ?></td>
      </tr>
      <tr>
        <th>Email</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($user->email); ?></td>
      </tr>
    </table>

    <!-- Tariff Details -->
    <h3>Tariff Details</h3>
    <table>
      <tr>
        <th>Title</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($tariff->title); ?></td>
      </tr>
      <tr>
        <th>Description</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($tariff->description); ?></td>
      </tr>
      <tr>
        <th>Note</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($tariff->note); ?></td>
      </tr>
      <tr>
        <th>Features</th>
        <td>
          <?php if($tariff->features): ?>
            <ul>
              <?php $__currentLoopData = json_decode($tariff->features); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo new \Illuminate\Support\EncodedHtmlString($feature); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          <?php endif; ?>
        </td>
      </tr>
      <tr>
        <th>Price</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString(number_format($tariff->price_cents / 100, 2)); ?> <?php echo new \Illuminate\Support\EncodedHtmlString($tariff->currency); ?></td>
      </tr>
    </table>

    <!-- Booking / Billing Details -->
    <h3>Billing Details</h3>
    <table>
      <tr>
        <th>Company</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->company); ?></td>
      </tr>
      <tr>
        <th>Company ID</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->company_id); ?></td>
      </tr>
      <tr>
        <th>VAT No.</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->tax_vat_no); ?></td>
      </tr>
      <tr>
        <th>Name</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->name); ?></td>
      </tr>
      <tr>
        <th>Address</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->address); ?></td>
      </tr>
      <tr>
        <th>City</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->city); ?></td>
      </tr>
      <tr>
        <th>Zip</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->zip); ?></td>
      </tr>
      <tr>
        <th>Country</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->country); ?></td>
      </tr>
      <tr>
        <th>Phone</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->phone); ?></td>
      </tr>
      <tr>
        <th>Email</th>
        <td><?php echo new \Illuminate\Support\EncodedHtmlString($booking->email); ?></td>
      </tr>
    </table>

    <p class="total">Total: <?php echo new \Illuminate\Support\EncodedHtmlString(number_format($tariff->price_cents / 100, 2)); ?> <?php echo new \Illuminate\Support\EncodedHtmlString($tariff->currency); ?></p>

    <div class="footer">
      <p>Thank you for your purchase!</p>
      <p>&copy; <?php echo new \Illuminate\Support\EncodedHtmlString(date('Y')); ?> Your Company Name</p>
    </div>
  </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/emails/invoiceTariffPurchase.blade.php ENDPATH**/ ?>