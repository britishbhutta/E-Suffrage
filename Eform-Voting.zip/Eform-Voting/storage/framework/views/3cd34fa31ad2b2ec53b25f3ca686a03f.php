<?php $__env->startComponent('mail::message'); ?>
# Hello <?php echo new \Illuminate\Support\EncodedHtmlString($firstName ?: 'there'); ?>,

Thanks for signing up — please use the verification code below to activate your account.

<?php $__env->startComponent('mail::panel'); ?>
**<?php echo new \Illuminate\Support\EncodedHtmlString($code); ?>**
<?php echo $__env->renderComponent(); ?>

This code will expire in 5 minutes.

If you did not register on our site, just ignore this email.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/emails/welcome.blade.php ENDPATH**/ ?>