
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
        <?php if(session('error')): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                Toastify({
                    text: "<?php echo e(session('error')); ?>",
                    duration: 3000, // 5 seconds
                    gravity: "top", // `top` or `bottom`
                    position: "right", // `left`, `center` or `right`
                    backgroundColor: "linear-gradient(to right, #ff5f6d, #ffc371)", // red/orange for error
                    stopOnFocus: true, // pause on hover
                    close: true
                }).showToast();
            });
        </script>
        
    <?php endif; ?>
    <?php $__env->stopPush(); ?>

    <div class="container py-4">
        <?php echo $__env->make('partials.voting-tabs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="wizard-progress-wrapper mb-4">
            <div class="progress-labels d-flex justify-content-between align-items-start">
                <?php $__currentLoopData = $stepNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a <?php if($num <= $currentStep): ?> href="<?php echo e(route('voting.create.step', ['step' => $num] + (request()->query() ? request()->query() : []))); ?>" <?php endif; ?>
                       class="progress-node text-center <?php echo e($num <= $currentStep ? 'active' : ''); ?>"
                       data-step="<?php echo e($num); ?>">
                        <div class="node-number"><?php echo e($num); ?></div>
                        <div class="node-name"><?php echo e($name); ?></div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="progress-bar-line" aria-hidden="true"></div>
            <div class="progress-active-line" style="width: <?php echo e((($currentStep - 1) / (count($stepNames) - 1)) * 88); ?>%;"></div>
        </div>

        
        <div class="card">
            <div class="card-body">
                <?php if($currentStep > 1 && empty($selectedTariff) && !session()->has('booking_id')): ?>
                    <div class="alert alert-warning mb-4">
                        Please Start From Step 1 For Proceeding.
                    </div>
                    <div class="d-flex justify-content-start">
                        <a href="<?php echo e(route('voting.create.step', ['step' => 1])); ?>" class="btn btn-light">Go back to Step 1</a>
                    </div>
                <?php else: ?>
                    <?php if($currentStep === 1): ?>
                        <?php echo $__env->make('partials.personal-info', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php elseif($currentStep === 2): ?>
                    
                        <?php if($booking->payment_status == 'succeeded'): ?>
                            <div class="alert alert-warning" role="alert">
                                Tariff can not be changed Because Payment Has Been Received for this Tariff. 
                            </div>
                        <?php endif; ?>
                    
                        <div class="selected-info-tariff text-muted mb-4">
                            <?php if(!empty($selectedTariff)): ?>

                            <?php else: ?>
                                No tariff selected
                            <?php endif; ?>
                            
                        </div>
                        
                        <?php echo $__env->make('partials.tariff-cards', ['tariffs' => $tariffs, 'selectedTariff' => $selectedTariff ?? null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <form method="POST" action="<?php echo e(route('voting.select_tariff')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="tariff" id="selectedTariffInput" value="<?php echo e($selectedTariff ? $selectedTariff->id : ''); ?>">

                        <div class="wizard-actions mt-4 d-flex justify-content-between align-items-center">
                            <div class="selected-info text-muted">
                                <?php if(!empty($selectedTariff)): ?>
                                    <!-- Selected: <?php echo e($selectedTariff->title); ?> -->
                                    <div class="form-check mt-2">
                                        <input class="form-check-input" type="checkbox" id="termsCheckbox">
                                        <label class="form-check-label" for="termsCheckbox">
                                            I agree to the <a href="" target="_blank">Terms & Conditions</a>
                                        </label>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div>
                            <div class="d-flex justify-content-between mt-4">
                                <?php
                                    $prev = ($currentStep ?? 3) - 1;
                                    $prevUrl = $prev >= 1 ? route('voting.create.step', ['step' => $prev]) : route('voting.realized');
                                ?>

                                <a href="<?php echo e($prevUrl); ?>" class="btn btn-light"><?php echo e($prev >= 1 ? 'Back' : 'Cancel'); ?></a>
                                <button type="submit" id="wizardNextBtn" class="btn btn-success" <?php echo e(empty($selectedTariff) ? 'disabled' : ''); ?>>Next</button>
                            </div>
                        </div>
                    </form>

                    <?php elseif($currentStep === 3): ?>
                        <?php if($booking->tariff_id == null): ?>
                            <div class="alert alert-warning mb-4">
                                Please Select Tariff To Proceed.
                            </div>
                            <div class="d-flex justify-content-start">
                                <a href="<?php echo e(route('voting.create.step', ['step' => 2])); ?>" class="btn btn-light">Go back to Step 2</a>
                            </div>
                        <?php else: ?>
                            
                            <?php echo $__env->make('partials.reward-form', ['selectedTariff' => $selectedTariff ?? null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endif; ?>
                    <?php elseif($currentStep === 4): ?>
                         <?php if($booking->tariff_id === null || is_null($rewardData)): ?>
                            <div class="alert alert-warning mb-4">
                                Please Complete Previous Steps to Proceed.
                            </div>
                            <div class="d-flex justify-content-start">
                                <a href="<?php echo e(route('voting.create.step', ['step' => 1])); ?>" class="btn btn-light">Go back to Step 1</a>
                            </div>
                        <?php else: ?>
                            <?php echo $__env->make('partials.details-form', ['selectedTariff' => $selectedTariff ?? null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endif; ?>
                    <?php elseif($currentStep === 5): ?>
                        
                        <?php if($booking->payment_status == 'succeeded'): ?>
                            <?php echo $__env->make('partials.payment-successfull', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php else: ?>
                            <?php if(is_null($booking->tariff_id)): ?>
                                <div class="alert alert-warning mb-4">
                                    Please Select Tariff From Step 2 For Proceeding.
                                </div>
                                <div class="d-flex justify-content-start">
                                    <a href="<?php echo e(route('voting.create.step', ['step' => 2])); ?>" class="btn btn-light">Go back to Step 2</a>
                                </div>
                            <?php else: ?>
                                <?php echo $__env->make('partials.payment', ['selectedTariff' => $selectedTariff ?? null, 'currentStep' => $currentStep], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($booking->payment_status == 'succeeded'): ?>
                            <?php echo $__env->make('partials.qr-code', ['booking' => $booking ?? null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                            <?php if(session('complete_errors')): ?>
                                <div class="alert alert-danger mt-3">
                                    <div class="fw-bold mb-2">Please resolve the following before finishing:</div>
                                    <ul class="mb-0">
                                        <?php $__currentLoopData = (array) session('complete_errors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($msg); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            
                            
                            <div class="d-flex justify-content-between mt-4">
                                
                                <?php
                                    $prev = $currentStep - 1;
                                    $prevUrl = $prev >= 1 ? route('voting.create.step', ['step' => $prev]) : route('voting.realized');
                                ?>
                                <a href="<?php echo e($prevUrl); ?>" class="btn btn-light"><?php echo e($prev >= 1 ? 'Back' : 'Cancel'); ?></a>
                                <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#finishOverviewModal">Finish</button> -->
                                <form method="POST" action="<?php echo e(route('voting.complete')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">
                                    <button type="submit" class="btn btn-success">Finish</button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning mb-4">
                                Please Complete Previous Steps to Proceed.
                            </div>
                            <div class="d-flex justify-content-start">
                                <a href="<?php echo e(route('voting.create.step', ['step' => 1])); ?>" class="btn btn-light">Go back to Step 1</a>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

         
        <?php if($currentStep === 2): ?>
            
        <?php endif; ?>
    </div>

    <!-- <?php if($currentStep === 6): ?>
        <div class="modal fade" id="finishOverviewModal" tabindex="-1" aria-labelledby="finishOverviewLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="finishOverviewLabel">Review your voting setup</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <h6>1) Tariff</h6>
                            <div class="text-muted"><?php echo e($selectedTariff?->title ?? '-'); ?> — <?php echo e($selectedTariff ? number_format($selectedTariff->price_cents/100,2) . ' ' . $selectedTariff->currency : ''); ?></div>
                        </div>
                        <div class="mb-3">
                            <h6>2) Billing / Booking</h6>
                            <?php if(!empty($booking)): ?>
                                <div class="small text-muted">
                                    <div><strong>Name:</strong> <?php echo e($booking->name ?? '-'); ?></div>
                                    <div><strong>Email:</strong> <?php echo e($booking->email ?? '-'); ?></div>
                                    <div><strong>Address:</strong> <?php echo e($booking->address ?? '-'); ?>, <?php echo e($booking->city ?? '-'); ?> <?php echo e($booking->zip ?? ''); ?></div>
                                    <div><strong>Country:</strong> <?php echo e($booking->country ?? '-'); ?></div>
                                    <div><strong>Reference:</strong> <?php echo e($booking->booking_reference ?? '-'); ?></div>
                                    <div><strong>Payment:</strong> <?php echo e(ucfirst($booking->payment_method ?? '-')); ?> (<?php echo e($booking->payment_status ?? '-'); ?>)</div>
                                </div>
                            <?php else: ?>
                                <div class="text-danger">No booking found.</div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <h6>3) Reward</h6>
                            <?php $reward = $booking?->reward; ?>
                            <div class="small text-muted">
                                <div><strong>Name:</strong> <?php echo e($reward->name ?? '-'); ?></div>
                                <div><strong>Description:</strong> <?php echo e($reward->description ?? '-'); ?></div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <h6>4) Voting Event</h6>
                            <?php $overviewEvent = isset($votingEvent) ? $votingEvent : (isset($booking) ? \App\Models\VotingEvent::with('options')->where('booking_id', $booking->id)->first() : null); ?>
                            <div class="small text-muted">
                                <div><strong>Title:</strong> <?php echo e($overviewEvent?->title ?? '-'); ?></div>
                                <div><strong>Question:</strong> <?php echo e($overviewEvent?->question ?? '-'); ?></div>


                                <div><strong>Start:</strong> <?php echo e($overviewEvent?->start_at ? \Carbon\Carbon::parse($overviewEvent->start_at)->setTimezone($timezone ?? config('app.timezone'))->format('M d, Y H:i T') : '-'); ?> <?php echo e($localTime); ?></div>
                                <div><strong>End:</strong> <?php echo e($overviewEvent?->end_at ? \Carbon\Carbon::parse($overviewEvent->end_at)->setTimezone($timezone ?? config('app.timezone'))->format('M d, Y H:i T') : '-'); ?> <?php echo e($localTime); ?></div>

                                <div><strong>Options:</strong>
                                    <?php if($overviewEvent && $overviewEvent->options->isNotEmpty()): ?>
                                        <ul class="mb-0">
                                            <?php $__currentLoopData = $overviewEvent->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($opt->option_text); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2">
                            <h6>5) QR Code</h6>
                            <div class="small text-muted">Your QR has been generated in Step 6.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <?php if(!empty($booking)): ?>
                        <form method="POST" action="<?php echo e(route('voting.complete')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">
                            <button type="submit" class="btn btn-success">Confirm Finish</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?> -->

    <?php $__env->startPush('scripts'); ?>
        
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const currentStep = Number(<?php echo json_encode($currentStep, 15, 512) ?>);
                document.querySelectorAll('.progress-node').forEach(function (node) {
                    const step = Number(node.getAttribute('data-step'));
                    if (step <= currentStep) {
                        node.classList.add('active');
                    } else {
                        node.classList.remove('active');
                    }
                });
    
                if (currentStep === 2) {
                    const cards = document.querySelectorAll('.selectable-card');
                    const nextBtn = document.getElementById('wizardNextBtn');
                    const selectedInfo = document.querySelector('.selected-info');
                    const selectedInfoTariff = document.querySelector('.selected-info-tariff');
                    const selectedInput = document.getElementById('selectedTariffInput');
                    const termsCheckbox = document.getElementById('termsCheckbox');
                    let selectedTariffId = <?php echo json_encode($selectedTariff ? $selectedTariff->id : '', 15, 512) ?>;

                    // Enable Next only when tariff + checkbox are valid
                    function updateNextButtonState() {
                        if (selectedTariffId && (!termsCheckbox || termsCheckbox.checked)) {
                            nextBtn.disabled = false;
                        } else {
                            nextBtn.disabled = true;
                        }
                    }

                    function setSelected(cardEl) {
                        cards.forEach(c => c.classList.remove('selected'));
                        cardEl.classList.add('selected');
                        selectedTariffId = cardEl.getAttribute('data-tariff-id');
                        const header = cardEl.querySelector('.card-header strong');
                        const title = header ? header.innerText : 'Tariff';

                        let isPaid = <?php echo json_encode($booking && $booking->payment_status === 'succeeded', 15, 512) ?>;

                        // Inject checkbox into DOM
                        selectedInfo.innerHTML = `
                            <div class="form-check mt-2">
                                <input class="form-check-input" type="checkbox" id="termsCheckbox" ${isPaid ? 'checked' : ''}>
                                <label class="form-check-label" for="termsCheckbox">
                                    I agree to the <a href="<?php echo e(route('terms.show')); ?>" target="_blank">Terms & Conditions</a>
                                </label>
                            </div>
                        `;
                        selectedInfoTariff.innerHTML = `
                        <strong>Selected: </strong> ${title} 
                        `;
                        selectedInput.value = selectedTariffId;

                        // Get new checkbox
                        const newCheckbox = document.getElementById('termsCheckbox');

                        if (isPaid) {
                            nextBtn.disabled = false;
                            if (newCheckbox) {
                                newCheckbox.disabled = true; 
                            }
                        } else {
                            nextBtn.disabled = true;
                            if (newCheckbox) {
                                newCheckbox.addEventListener('change', function () {
                                    nextBtn.disabled = !this.checked;
                                });
                            }
                        }
                    }

                    cards.forEach(card => {
                        card.addEventListener('click', function () {
                            setSelected(this);
                        });
                        card.addEventListener('keydown', function (e) {
                            if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault();
                                setSelected(this);
                            }
                        });
                        const btn = card.querySelector('.select-btn');
                        if (btn) {
                            btn.addEventListener('click', function (ev) {
                                ev.stopPropagation();
                                setSelected(card);
                            });
                        }
                    });

                    // Attach listener if checkbox already in DOM
                    if (termsCheckbox) {
                        termsCheckbox.addEventListener('change', updateNextButtonState);
                    }

                    // Initialize state if already selected
                    if (selectedTariffId) {
                        const initialCard = [...cards].find(c => c.getAttribute('data-tariff-id') === selectedTariffId.toString());
                        if (initialCard) {
                            setSelected(initialCard);
                        }
                    } else {
                        updateNextButtonState();
                    }
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/voting/step.blade.php ENDPATH**/ ?>