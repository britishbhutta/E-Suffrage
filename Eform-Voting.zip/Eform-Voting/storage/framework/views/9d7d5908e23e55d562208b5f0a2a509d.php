

 

 
<div class="row g-2 justify-content-center wizard-cards">
    <?php $__empty_1 = true; $__currentLoopData = $tariffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tariff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-12 col-sm-6 col-md-4 col-lg-3">
            <?php if($booking->payment_status === "succeeded"): ?>
                <?php if($booking->tariff_id === $tariff->id): ?>
                    <div class="card tariff-card tariff-card-compact selectable-card <?php echo e((!empty($selectedTariff) && $selectedTariff->id === $tariff->id) ? 'selected' : ''); ?>" data-tariff-id="<?php echo e($tariff->id); ?>" tabindex="0" role="button" aria-pressed="<?php echo e((!empty($selectedTariff) && $selectedTariff->id === $tariff->id) ? 'true' : 'false'); ?>">
                <?php else: ?>
                    <div class="card tariff-card tariff-card-compact <?php echo e((!empty($selectedTariff) && $selectedTariff->id === $tariff->id) ? 'selected' : ''); ?>" data-tariff-id="<?php echo e($tariff->id); ?>" tabindex="0" role="button" aria-pressed="<?php echo e((!empty($selectedTariff) && $selectedTariff->id === $tariff->id) ? 'true' : 'false'); ?>">
                <?php endif; ?>
            <?php else: ?>
                    <div class="card tariff-card tariff-card-compact selectable-card <?php echo e((!empty($selectedTariff) && $selectedTariff->id === $tariff->id) ? 'selected' : ''); ?>" data-tariff-id="<?php echo e($tariff->id); ?>" tabindex="0" role="button" aria-pressed="<?php echo e((!empty($selectedTariff) && $selectedTariff->id === $tariff->id) ? 'true' : 'false'); ?>">
            <?php endif; ?>
                <div class="card-header text-center">
                    <strong><?php echo e($tariff->title); ?></strong>
                </div>
                <div class="card-body d-flex flex-column">
                    <p class="tariff-range mb-2"><?php echo e($tariff->description); ?></p>
                    <p class="tariff-note text-muted small mb-3"><?php echo e($tariff->note); ?></p>
                    <div class="price-wrapper text-center mb-2">
                        <div class="price"><strong><?php echo e(number_format($tariff->price_cents / 100, 2)); ?> <?php echo e($tariff->currency); ?></strong></div>
                        <div class="price-underline"></div>
                    </div>
                    <ul class="list-unstyled mb-3 tariff-features">
                        <?php $__currentLoopData = (array) json_decode($tariff->features ?? '[]', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>✓ <?php echo e($feature); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="mt-auto text-center">
                        <button type="button" class="btn btn-outline-dark select-btn" aria-label="Select <?php echo e($tariff->title); ?>">Select</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="alert alert-info">No tariff plans available at the moment.</div>
        </div>
    <?php endif; ?>

    
</div>
 
 <?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/partials/tariff-cards.blade.php ENDPATH**/ ?>