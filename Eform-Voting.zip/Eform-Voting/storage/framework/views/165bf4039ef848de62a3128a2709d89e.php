<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom stylesheet (moved from inline styles) -->
        <link href="<?php echo e(asset('css/auth.css')); ?>" rel="stylesheet">
        <style>
            body { background-color: #f8f9fa; }
            .voting-card { max-width: 600px; margin: 2rem auto; }
            .voting-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        </style>
    <?php $__env->stopPush(); ?>
        
    <div class="container form-card">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <div class="text-center mb-3">
            <h1 class="fw-bold">Log in</h1>
        </div>
        

        <!-- success messege -->
        
        <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?>

              <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                  <?php echo e(session('success')); ?>

                </div>
              <?php endif; ?>

              <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                  <?php echo e(session('error')); ?>

                </div>
              <?php endif; ?>

              
              <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                  <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              <?php endif; ?>


        
        <?php if(session()->has('votingEvent')): ?>
            <div class="container">
                <div class="voting-card">
                    <div class="card voting-header mb-3">
                        <div class="card-body text-center">
                            <h2 class="card-title mb-2"><?php echo e(session('votingEvent')); ?></h2>
                        </div>
                    </div>
        <?php endif; ?>
                    <div class="card shadow-sm border-0">
                        <div class="card-body p-4 p-md-5">
                            <form method="POST" action="<?php echo e(route('login')); ?>" novalidate>
                                <?php echo csrf_field(); ?>

                                <!-- Email -->
                                <div class="mb-3">
                                    <label class="form-label" for="email">Email</label>
                                    <input id="email" name="email" type="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        value="<?php echo e(old('email')); ?>" required autofocus autocomplete="username">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Password -->
                                <div class="mb-3 position-relative">
                                    <div class="d-flex justify-content-between align-items-center">
                                <label class="form-label mb-0" for="password">Password</label>
                                </div>
                                <div class="password-wrapper">
                                <input id="password" name="password" type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required autocomplete="current-password">
                                    <button type="button" id="toggleLoginPassword" class="password-toggle" tabindex="-1" aria-label="Toggle password visibility">
                                    <!-- eye icon -->
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" 
                                    fill="none" stroke="currentColor" stroke-width="2" 
                                    stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                    </svg>
                                    </button>
                                        </div>

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>


                                <!-- hCaptcha -->
                                <div class="mt-4">
                                    <div class="h-captcha" data-sitekey="<?php echo e(env('HCAPTCHA_SITEKEY')); ?>" data-size="normal"></div>
                                    <?php $__errorArgs = ['h-captcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Remember + Forgot Password -->
                                <div class="d-flex justify-content-between align-items-center mb-3 mt-3">
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="checkbox" id="remember_me" name="remember">
                                        <label class="form-check-label" for="remember_me">Remember me</label>
                                    </div>
                                    <?php if(Route::has('password.request')): ?>
                                        <a href="<?php echo e(route('password.request')); ?>" class="small text-secondary link-underline-hover">Forgot password?</a>
                                    <?php endif; ?>
                                </div>

                                <!-- Submit -->
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-blue">Log in</button>
                                </div>

                                <!-- OR divider -->
                                <div class="d-flex align-items-center my-3 text-muted">
                                    <hr class="flex-grow-1">
                                    <span class="px-2 small text-uppercase">or</span>
                                    <hr class="flex-grow-1">
                                </div>

                                <!-- Social buttons -->
                                <div class="d-grid gap-2">
                                <!-- Apple button -->
                                    <button type="button" class="social-btn w-100 w-md-auto">&nbsp; Continue with Apple</button>

                                    

                                    <a href="<?php echo e(route('google.login')); ?>"
                                    class="btn-google social-btn w-100"
                                    aria-label="Continue with Google">
                                        <img src="https://www.svgrepo.com/show/355037/google.svg" alt="G" class="btn-google-icon">
                                        Continue with Google
                                    </a>
                                </div>
                            </form>

                            <!-- SIGNUP BLOCK: placed under form, matches page UI -->
                            <div class="signup-block text-center mt-3">
                                <p class="small small-muted mb-2">Don't have an account?</p>

                                <!-- Primary CTA (outline but prominent) -->
                                <a href="<?php echo e(session()->has('eventToken') ? url('register') : url('/')); ?>"
                                    class="btn btn-outline-primary w-100 btn-create-account"
                                    aria-label="Create an account">
                                    Create an account
                                </a>
                            </div>

                        </div>
                    </div>
        <?php if(session()->has('votingEvent')): ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
    document.getElementById('toggleLoginPassword').addEventListener('click', function () {
        const passwordInput = document.getElementById('password');
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
    });
    </script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const alerts = document.querySelectorAll('.alert');
        if (alerts) {
            setTimeout(() => {
                alerts.forEach(alert => {
                    alert.classList.add('fade');
                    alert.classList.add('show');

                    setTimeout(() => {
                        alert.remove();
                    }, 500); 
                });
            }, 3000); 
        }
    });
</script>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://hcaptcha.com/1/api.js" async defer></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>



<?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/auth/login.blade.php ENDPATH**/ ?>