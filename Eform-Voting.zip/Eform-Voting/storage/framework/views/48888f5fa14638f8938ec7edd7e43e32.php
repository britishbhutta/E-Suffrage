
<?php
    $currentStep = $currentStep ?? 5;

    $prev = $currentStep - 1;
    $prevUrl = $prev >= 1
        ? route('voting.create.step', ['step' => $prev] + (request()->query() ? request()->query() : []))
        : route('voting.realized');

    $bookingId = $booking->id ?? session('voting.booking_id') ?? old('booking_id') ?? request()->input('booking_id');

    $votingData = $votingData ?? [
        'form_name' => '',
        'question' => '',
        'start_at' => '',
        'end_at' => '',
        'options' => [],
    ];

    $initialOptions = old('options') ?? ($votingData['options'] ?? []);
    $initialCount = max(4, count($initialOptions));
?>

<form class="details-form reward-form" method="POST" action="<?php echo e(route('voting.create.step', ['step' => $currentStep])); ?>" enctype="multipart/form-data" novalidate>
    <?php echo csrf_field(); ?>

    <!-- <?php if($bookingId): ?>
        <input type="hidden" name="booking_id" value="<?php echo e($bookingId); ?>">
    <?php endif; ?> -->

    <div class="mb-3">
        <label for="form_name" class="form-label">Name of Voting Form*</label>
        <input type="text" class="form-control <?php $__errorArgs = ['form_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="form_name" name="form_name" placeholder="e.g. Best Player of the Match" required value="<?php echo e(old('form_name', $votingData['form_name'] ?? '')); ?>">
        <?php $__errorArgs = ['form_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="row g-3">
        <div class="col-md-6">
            <label for="start_at" class="form-label">
                Voting Start (Date & Time)* 
                <?php if($localTime): ?>
                    <small class="text-muted"> <?php echo e($localTime); ?></small>
                <?php endif; ?>
            </label>
            <input type="datetime-local" class="form-control <?php $__errorArgs = ['start_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="start_at" name="start_at" required value="<?php echo e(old('start_at', $votingData['start_at'] ?? '')); ?>">
            <?php $__errorArgs = ['start_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label for="end_at" class="form-label">
                Voting End (Date & Time)*
                <?php if($localTime): ?>
                    <small class="text-muted"> <?php echo e($localTime); ?></small>
                <?php endif; ?>
            </label>
            <input type="datetime-local" class="form-control <?php $__errorArgs = ['end_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="end_at" name="end_at" required value="<?php echo e(old('end_at', $votingData['end_at'] ?? '')); ?>">
            <?php $__errorArgs = ['end_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="mb-3 mt-2">
        <label for="question" class="form-label">Voting Question*</label>
        <textarea class="form-control <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="question" name="question" rows="2" placeholder="Write the question participants will see" required><?php echo e(old('question', $votingData['question'] ?? '')); ?></textarea>
        <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
        <label class="form-label">Voting Options*</label>
        <div class="options-list" id="optionsList">
            <?php for($i = 0; $i < $initialCount; $i++): ?>
                <?php $val = $initialOptions[$i] ?? ''; ?>
                <div class="option-item mb-2">
                    <input type="text" class="form-control <?php $__errorArgs = ['options.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="option<?php echo e($i+1); ?>" name="options[]" placeholder="Option <?php echo e($i+1); ?>" value="<?php echo e($val); ?>">
                    <?php $__errorArgs = ['options.'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endfor; ?>
        </div>

        <div class="text-end">
            <button type="button" class="btn btn-success btn-sm mt-2" id="addOptionBtn">
                + Add Option
            </button>
        </div>
    </div>

    <div class="d-flex justify-content-between mt-4">
        <a href="<?php echo e($prevUrl); ?>" class="btn btn-light"><?php echo e($prev >= 1 ? 'Back' : 'Cancel'); ?></a>

        <button type="submit" id="detailsNextBtn" class="btn btn-success">Save</button>
    </div>
</form>
<!-- Confirmation Modal -->
<div class="modal fade" id="finishOverviewModal" tabindex="-1" aria-labelledby="finishOverviewLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="finishOverviewLabel">Review your voting setup</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <h6>1) Tariff</h6>
                    <div><?php echo e($selectedTariff?->title ?? '-'); ?> — <?php echo e($selectedTariff ? number_format($selectedTariff->price_cents/100,2) . ' ' . $selectedTariff->currency : ''); ?></div>
                </div>
                <div class="mb-3">
                    <h6>2) Billing / Booking</h6>
                    <?php if(!empty($booking)): ?>
                        <div class="small">
                            <div><strong>Name:</strong> <?php echo e($booking->name ?? '-'); ?></div>
                            <div><strong>Email:</strong> <?php echo e($booking->email ?? '-'); ?></div>
                            <div><strong>Address:</strong> <?php echo e($booking->address ?? '-'); ?>, <?php echo e($booking->city ?? '-'); ?> <?php echo e($booking->zip ?? ''); ?></div>
                            <div><strong>Country:</strong> <?php echo e($booking->country ?? '-'); ?></div>
                            <div><strong>Reference:</strong> <?php echo e($booking->booking_reference ?? '-'); ?></div>
                        </div>
                    <?php else: ?>
                        <div class="text-danger">No booking found.</div>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <h6>3) Reward</h6>
                    <?php $reward = $booking?->reward; ?>
                    <div class="small">
                        <div><strong>Name:</strong> <?php echo e($reward->name ?? '-'); ?></div>
                        <div><strong>Description:</strong> <?php echo e($reward->description ?? '-'); ?></div>
                    </div>
                </div>
                <div class="mb-3">
                    <h6>4) Voting Event</h6>
                    <?php $overviewEvent = isset($votingEvent) ? $votingEvent : (isset($booking) ? \App\Models\VotingEvent::with('options')->where('booking_id', $booking->id)->first() : null); ?>
                    <div class="small" id="modal-form-detail">
                        <div><strong>Title:</strong> <?php echo e($overviewEvent?->title ?? '-'); ?></div>
                        <div><strong>Question:</strong> <?php echo e($overviewEvent?->question ?? '-'); ?></div>


                        
                        <div><strong>Options:</strong>
                            <?php if($overviewEvent && $overviewEvent->options->isNotEmpty()): ?>
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $overviewEvent->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($opt->option_text); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="mb-2">
                    <h6>5) QR Code</h6>
                    <div class="small">Your QR Code would generate after the Payment.</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                <?php if(!empty($booking)): ?>
                    <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">
                    <a href="<?php echo e(route('voting.create.step', ['step' => 5])); ?>" type="submit" class="btn btn-success">Confirm & Next</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
  

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('/')); ?>js/step4-ajax.js"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/partials/details-form.blade.php ENDPATH**/ ?>