<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>     
    <?php $__env->startPush('styles'); ?>
        <style>
            body { background-color: #f8f9fa; }
            .voting-card { max-width: 600px; margin: 2rem auto; }
            .option-card { cursor: pointer; transition: all 0.3s ease; }
            .option-card:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
            .option-card.selected { border-color: #0d6efd; background-color: #f8f9ff; }
            .voting-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        </style>
    <?php $__env->stopPush(); ?>
        <div class="container">
            <div class="text-center">
                <span class="fw-bold fs-5">Voting Form - Reward</span>
                <span class="fw-bold fs-5">" <?php echo e($reward->name); ?> "</span>
            </div>
            <div class="voting-card">
                <div class="card voting-header">
                    <div class="card-body text-center">
                        <h2 class="card-title mb-2"><?php echo e($votingEvent->title); ?></h2>
                        <p class="card-text mb-0"><?php echo e($votingEvent->question); ?></p>
                    </div>
                </div>

                <div class="card mt-3">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Select your option:</h5>
                        
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                        
                        <form id="votingForm" method="POST" action="<?php echo e(route('voting.submit', ['token' => $votingEvent->token])); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <?php $__currentLoopData = $votingEvent->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 mb-3">
                                        <div class="card option-card h-100" data-option-id="<?php echo e($option->id); ?>">
                                            <div class="card-body text-center">
                                                <div class="form-check">
                                                    <?php if(Auth::check()): ?>
                                                        <input class="form-check-input" type="radio" name="selected_option" 
                                                        id="option_<?php echo e($option->id); ?>" value="<?php echo e($option->id); ?>" required>
                                                    <?php endif; ?>
                                                    <label class="form-check-label" for="option_<?php echo e($option->id); ?>">
                                                        <?php echo e($option->option_text); ?>

                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <?php $__errorArgs = ['selected_option'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger mt-3">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <?php if(Auth::check()): ?>
                                <div class="text-center mt-4">
                                    <button type="submit" class="btn btn-primary btn-lg px-5" id="submitBtn">
                                        Submit Vote
                                    </button>
                                </div>
                            <?php else: ?>
                                <div class="mt-4 text-center mb-4">
                                    <a href="<?php echo e(route('login')); ?>" class="fw-bold text-decoration-none text-primary">
                                        Join The Voting
                                        &nbsp; | &nbsp;
                                        Log In or Register
                                    </a>
                                </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>

                <div class="card mt-3">
                    <div class="card-body text-center text-muted">
                        <small>
                            <strong>Voting Period:</strong><br>
                            <?php if($votingEvent->start_at): ?>
                                Start: <?php echo e(\Carbon\Carbon::parse($votingEvent->start_at)->format('M d, Y H:i')); ?>

                            <?php endif; ?>
                            <?php if($votingEvent->end_at): ?>
                                <br>End: <?php echo e(\Carbon\Carbon::parse($votingEvent->end_at)->format('M d, Y H:i')); ?>

                            <?php endif; ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const optionCards = document.querySelectorAll('.option-card');
                const form = document.getElementById('votingForm');
                const submitBtn = document.getElementById('submitBtn');

                // Handle option selection
                optionCards.forEach(card => {
                    card.addEventListener('click', function() {
                        const radio = this.querySelector('input[type="radio"]');
                        radio.checked = true;
                        
                        // Update visual selection
                        optionCards.forEach(c => c.classList.remove('selected'));
                        this.classList.add('selected');
                    });
                });

                // Handle form submission
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const selectedOption = document.querySelector('input[name="selected_option"]:checked');
                    if (!selectedOption) {
                        alert('Please select an option before submitting.');
                        return;
                    }

                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Submitting...';

                    // Submit the form
                    this.submit();
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> 
<?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/voting/public/vote.blade.php ENDPATH**/ ?>