<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> 
    <?php $__env->startPush('styles'); ?>
        <style>
            body { background-color: #f8f9fa; }
            .voting-card { max-width: 600px; margin: 2rem auto; }
            .voting-header { background: linear-gradient(135deg, #6c757d 0%, #495057 100%); color: white; }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="container">
        <div class="text-center">
                <span class="fw-bold fs-5">Voting Form - Reward</span>
                <span class="fw-bold fs-5">" <?php echo e($reward->name); ?> "</span>
            </div>
        <div class="voting-card">
            <div class="card voting-header">
                <div class="card-body text-center">
                    <h2 class="card-title mb-2"><?php echo e($votingEvent->title); ?></h2>
                    <p class="card-text mb-0"><?php echo e($votingEvent->question); ?></p>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-body text-center">
                    <div class="mb-4">
                        <i class="fas fa-calendar-times fa-3x text-secondary mb-3"></i>
                        <h4>Voting Has Ended</h4>
                        <p class="text-muted">This voting event ended on:</p>
                        <h5 class="text-secondary"><?php echo e(\Carbon\Carbon::parse($votingEvent->end_at)->format('M d, Y \a\t H:i')); ?></h5>
                    </div>
                    <?php if(!Auth::check()): ?>
                            <div class="mt-4 text-center mb-4">
                                <a href="<?php echo e(route('login')); ?>" class="fw-bold text-decoration-none text-primary">
                                    Join The Voting
                                    &nbsp; | &nbsp;
                                    Log In or Register
                                </a>
                            </div>
                        <?php endif; ?>
                    <div class="alert alert-secondary">
                        <strong>Voting Period:</strong><br>
                        <?php if($votingEvent->start_at): ?>
                            Start: <?php echo e(\Carbon\Carbon::parse($votingEvent->start_at)->format('M d, Y H:i')); ?><br>
                        <?php endif; ?>
                        End: <?php echo e(\Carbon\Carbon::parse($votingEvent->end_at)->format('M d, Y H:i')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> 

<?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/voting/public/ended.blade.php ENDPATH**/ ?>