<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
    <style>
        
        /* hide unwanted fields from Stripe Address Element */
            .StripeElement--address input[name="name"],
            .StripeElement--address input[name="line1"],
            .StripeElement--address input[name="line2"],
            .StripeElement--address input[name="city"],
            .StripeElement--address input[name="postal_code"],
            .StripeElement--address select[name="country"] {
                display: none !important;
            }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@25.10.1/build/css/intlTelInput.css">
    <?php if($errors->any()): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    Toastify({
                        text: "<?php echo e($error); ?>",
                        duration: 3000,
                        gravity: "top", 
                        position: "right", 
                        backgroundColor: "linear-gradient(to right, #ff5f6d, #ffc371)",
                        stopOnFocus: true,
                        close: true
                    }).showToast();
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            });
        </script>
    <?php endif; ?>
            
<?php $__env->stopPush(); ?>

<div class="container d-flex justify-content-center">
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-sm p-4">
                <h5 class="text-center mb-5">Personal Information</h5>
                <form action="<?php echo e(route('voting.create.step',['step' => 1])); ?>" id="personal-info-form" method="POST">
                    <?php echo csrf_field(); ?>
                    <!-- Email -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">Email*</label>
                        <div class="col-sm-9">
                        <input type="email" name="email" class="form-control" placeholder="Enter your email" value="<?php echo e(old('email', $personalInfoData['email'] ?? '')); ?>" required>
                        <div class="invalid-feedback">Please enter a valid email.</div>
                        </div>
                    </div>

                    <!-- Phone -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">Phone Number</label>
                        <div class="col-sm-9">
                            <input type="tel" id="phone" placeholder="" id="telephone" name="phone" value="<?php echo e(old('phone', $personalInfoData['phone'] ?? '')); ?>" class="form-control" inputmode="numeric" maxlength="15"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '')"
                                placeholder="Phone" style="width: 400px;" required>
                                <div class="invalid-feedback">Please enter Phone Number.</div>
                        </div>
                    </div>

                    <!-- Invoice Checkbox (full width) -->
                    <div class="row mb-2">
                        <div class="col-sm-12">
                            <div class="form-check">
                                <input class="form-check-input"
                                    type="checkbox"
                                    name="invoice_issue"
                                    id="invoiceCompany"
                                    <?php if(($personalInfoData['invoice_issue'] ?? 0) == 1): ?> checked <?php endif; ?>>

                                <label class="form-check-label" for="invoiceCompany">
                                    Invoice issued to a company 
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Company -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">Company*</label>
                        <div class="col-sm-9">
                            <input type="text" name="company" class="form-control" placeholder="Enter company name" value="<?php echo e(old('company', $personalInfoData['company'] ?? '')); ?>" required>
                            <div class="invalid-feedback">Please enter Company Name.</div>
                        </div>
                    </div>

                    <!-- Company ID -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">Company ID*</label>
                        <div class="col-sm-9">
                        <input type="text" name="company_id" class="form-control" placeholder="Enter company ID" value="<?php echo e(old('company_id', $personalInfoData['company_id'] ?? '')); ?>" required>
                        <div class="invalid-feedback">Please enter Company ID.</div>
                        </div>
                    </div>

                    <!-- Tax/VAT Number -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">Tax/VAT Number</label>
                        <div class="col-sm-9">
                        <input type="text" name="tax_vat_no" class="form-control" placeholder="Enter tax/VAT number" value="<?php echo e(old('tax_vat_no', $personalInfoData['tax_vat_no'] ?? '')); ?>">
                        <div class="invalid-feedback">Please enter Tax/Vat Number.</div>
                        </div>
                    </div>

                    <!-- First Name -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">First Name *</label>
                        <div class="col-sm-9">
                        <input type="text" name="fname" class="form-control" placeholder="Enter first name" value="<?php echo e(old('fname', $personalInfoData['fname'] ?? '')); ?>" required>
                        <div class="invalid-feedback">Please enter First Name.</div>
                        </div>
                    </div>

                    <!-- Last Name -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">Last Name *</label>
                        <div class="col-sm-9">
                        <input type="text" name="lname" class="form-control" placeholder="Enter last name" value="<?php echo e(old('lname', $personalInfoData['lname'] ?? '')); ?>" required>
                        <div class="invalid-feedback">Please enter Last Name.</div>
                        </div>
                    </div>

                    <!-- Address -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">Address*</label>
                        <div class="col-sm-9">
                        <input type="text" name="address" class="form-control" placeholder="Enter address" value="<?php echo e(old('address', $personalInfoData['address'] ?? '')); ?>" required>
                        <div class="invalid-feedback">Please Enter Address.</div>
                        </div>
                    </div>

                    <!-- City -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">City*</label>
                        <div class="col-sm-9">
                        <input type="text" name="city" class="form-control" placeholder="Enter city" value="<?php echo e(old('city', $personalInfoData['city'] ?? '')); ?>" required>
                        <div class="invalid-feedback">Please Enter City.</div>
                        </div>
                    </div>

                    <!-- ZIP -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">ZIP*</label>
                        <div class="col-sm-9">
                        <input type="text" name="zip" class="form-control" placeholder="Enter ZIP code" value="<?php echo e(old('zip', $personalInfoData['zip'] ?? '')); ?>" required>
                        <div class="invalid-feedback">Please enter a valid Zip Code.</div>
                        </div>
                    </div>

                    <!-- Country -->
                    <div class="row align-items-center mb-2">
                        <label class="col-sm-3 col-form-label">Country*</label>
                        <div class="col-sm-9">
                            <select name="country" id="country-select" class="form-control" required>
                                <option value=""><?php echo e($countries->isEmpty() ? 'No countries available' : 'Select Country'); ?></option>

                                
                                <?php if(!empty($personalInfoData['country'])): ?>
                                    <option value="<?php echo e($personalInfoData['country']); ?>" 
                                        <?php echo e(old('country_id', $personalInfoData['country'] ?? '') == $personalInfoData['country'] ? 'selected' : ''); ?>>
                                        <?php echo e($personalInfoData['country_name'] ?? ''); ?>

                                    </option>
                                <?php endif; ?>

                                
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>" 
                                        <?php echo e(old('country_id', $personalInfoData['country'] ?? '') == $country->id ? 'selected' : ''); ?>>
                                        <?php echo e($country->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">Please Select Country.</div>
                        </div>
                    </div>
                    <div class="form-check mt-2">
                        <input class="form-check-input"
                            type="checkbox"
                            id="rememberMe"
                            name="remember_me"
                            <?php if(($personalInfoData['remember_me'] ?? 0) == 1): ?> checked <?php endif; ?>>

                        <label class="form-check-label" for="rememberMe">
                            Remember me 
                        </label>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div> 

<div class="d-flex justify-content-between mt-4">
    <?php
        $nextStep = ($currentStep ?? 1) + 1;
        $nextBase = route('voting.create.step', ['step' => $nextStep]);
        $qs = request()->getQueryString();
        $nextUrl = $nextBase . ($qs ? ('?' . $qs) : '');
    ?>
    
    <a href="<?php echo e(route('voting.realized')); ?>" class="btn btn-light me-2">Cancel</a>

    
    <button type="button" id="selectTariffNextBtn" class="btn btn-success">Next</button>
</div>
<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/intl-tel-input@25.10.1/build/js/intlTelInput.min.js"></script>
    <script type="text/javascript">
        const input = document.querySelector("#phone");

        // This comes from Laravel: e.g. "IN", "US", "DE"
        let initialCountryCode = <?php echo json_encode(old('countryCode', $personalInfoData['countryISOCode'] ?? ''), 512) ?>;
        

        const iti = window.intlTelInput(input, {
            initialCountry: initialCountryCode ? initialCountryCode.toLowerCase() : "auto",
            utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@25.10.1/build/js/utils.js"
        });

        // Only fallback to ipapi if we don’t already have a country
        if (!initialCountryCode) {
            fetch("https://ipapi.co/country/")
                .then(res => res.text())
                .then(countryCode => {
                    iti.setCountry(countryCode.toLowerCase());
                });
        }
    </script>

    <script>
        document.getElementById("selectTariffNextBtn").addEventListener("click", function () {
            let form = document.getElementById("personal-info-form");
            let inputs = form.querySelectorAll("input, select, textarea");

            let valid = true;

            inputs.forEach(function(input) {
                // Reset previous states
                input.classList.remove("is-valid", "is-invalid");

                // If field is required OR has a value, validate it
                if (input.required || input.value.trim() !== "") {
                    if (!input.checkValidity()) {
                        input.classList.add("is-invalid");
                        valid = false;
                    } else {
                        input.classList.add("is-valid");
                    }
                }
            });

            if (valid) {
                let rawNumber = input.value;
                if (rawNumber.startsWith("0")) {
                    rawNumber = rawNumber.substring(1);
                }
                let countryCode = iti.getSelectedCountryData().dialCode;
               //$('#phone').val(countryCode + rawNumber);
                $('#phone').val(countryCode + '-' + rawNumber);
                form.submit(); // safe now
            }

        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\Eform-Voting\resources\views/partials/personal-info.blade.php ENDPATH**/ ?>